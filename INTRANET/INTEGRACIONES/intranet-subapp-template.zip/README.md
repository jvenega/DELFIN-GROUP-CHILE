Intranet Sub-App Template

Template base oficial.